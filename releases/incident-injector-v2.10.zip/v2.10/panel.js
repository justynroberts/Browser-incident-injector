// Incident Injector - Panel Script
// This script provides the functionality for the slide-out panel
(function() {
    'use strict';

    // Page localStorage throws in sandboxed frames and on opaque origins;
    // never let that abort the script. chrome.storage.sync stays the source of truth.
    const safeStorage = {
        get(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } },
        set(key, value) { try { window.localStorage.setItem(key, value); } catch (e) { /* ignore */ } }
    };

    // Trusted Types policy — panel.js runs in the page's main world, so pages
    // that enforce `require-trusted-types-for 'script'` will reject raw string
    // assignments to innerHTML. Pass-through policy; all HTML we assign is
    // extension-owned.
    const trustedHTMLPolicy = (() => {
        try {
            if (window.trustedTypes && typeof window.trustedTypes.createPolicy === 'function') {
                return window.trustedTypes.createPolicy('incident-injector-panel', {
                    createHTML: (s) => s,
                    createScriptURL: (s) => s,
                    createScript: (s) => s
                });
            }
        } catch (e) {
            console.warn('[Panel] Could not create TrustedTypes policy, falling back:', e.message);
        }
        return null;
    })();
    function toTrustedHTML(html) {
        return trustedHTMLPolicy ? trustedHTMLPolicy.createHTML(html) : html;
    }

    // Helper function to check if Chrome extension API is available
    function isExtensionContext() {
        try {
            // Check if Chrome API exists and is functional
            if (typeof chrome === 'undefined' || !chrome) {
                console.log('[Panel] Chrome object is undefined');
                return false;
            }
            
            // Use try-catch for each property access to avoid errors
            try {
                if (!chrome.storage) {
                    console.log('[Panel] chrome.storage is not available');
                    return false;
                }
            } catch (e) {
                console.log('[Panel] Error accessing chrome.storage:', e.message);
                return false;
            }
            
            try {
                if (!chrome.storage.sync) {
                    console.log('[Panel] chrome.storage.sync is not available');
                    return false;
                }
            } catch (e) {
                console.log('[Panel] Error accessing chrome.storage.sync:', e.message);
                return false;
            }
            
            try {
                if (!chrome.runtime) {
                    console.log('[Panel] chrome.runtime is not available');
                    return false;
                }
            } catch (e) {
                console.log('[Panel] Error accessing chrome.runtime:', e.message);
                return false;
            }
            
            // Check if functions exist
            try {
                if (typeof chrome.storage.sync.get !== 'function' ||
                    typeof chrome.storage.sync.set !== 'function') {
                    console.log('[Panel] Chrome storage sync functions not available');
                    return false;
                }
            } catch (e) {
                console.log('[Panel] Error checking chrome.storage.sync functions:', e.message);
                return false;
            }
            
            try {
                if (typeof chrome.runtime.sendMessage !== 'function') {
                    console.log('[Panel] Chrome runtime.sendMessage not available');
                    return false;
                }
            } catch (e) {
                console.log('[Panel] Error checking chrome.runtime.sendMessage:', e.message);
                return false;
            }
            
            // Try a simple test to see if the extension context is valid
            // If the extension was reloaded, this might throw an error
            try {
                chrome.runtime.id; // This will throw if context is invalidated
                console.log('[Panel] Extension context is valid');
                return true;
            } catch (contextError) {
                console.log('[Panel] Extension context invalidated:', contextError.message);
                return false;
            }
        } catch (e) {
            console.log('[Panel] Running in page context - Chrome APIs not available:', e.message);
            return false;
        }
    }
    
    // More permissive check for runtime features
    function hasRuntimeAPI() {
        try {
            // Check if chrome.runtime exists and has the methods we need
            return typeof chrome !== 'undefined' && 
                   chrome.runtime && 
                   typeof chrome.runtime.sendMessage === 'function';
        } catch (e) {
            console.log('[Panel] Chrome runtime API not available');
            return false;
        }
    }
    
    // Initialize panel when it's loaded
    function initializePanel() {
        
        // Wait for panel DOM to be ready
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) {
            console.error('[Panel] Panel element not found');
            return;
        }
        
        // Initialize panel functionality
        initializePanelFunctionality();
        
    }
    
    // Store loaded settings globally for use across functions
    let loadedSettings = {};
    
    // Initialize all panel functionality (adapted from popup.js)
    async function initializePanelFunctionality() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        try {
            // Load saved settings
            loadedSettings = await loadSettings();
            
            // Update status
            updateStatus();

            // Initialize toggle sections
            initializeToggleSections();
            
            // Ensure sections remain collapsed after initialization
            ensureSectionsCollapsed();

            // Console-UI extras: armed state, summaries, about sheet, JSON format, multi-run
            initConsoleUi();
            
            // Initialize trigger options
            initializeTriggerOptions();
            
            // Initialize click interception
            initializeClickInterception();
            
            // Load event definition if exists
            const eventDefinitionTextarea = panel.querySelector('#event-definition');
            const scenarioControls = panel.querySelector('#scenario-controls');
            
            // Load event definition with fallback support
            let localResult = {};
            if (isExtensionContext()) {
                localResult = await chrome.storage.local.get(['event_definition']);
            } else {
                // Fallback: communicate through content script for local storage
                try {
                    const response = await new Promise((resolve, reject) => {
                        const messageHandler = (event) => {
                            if (event.data.action === 'load_local_settings_response' && event.data.source === 'incident-injector-content') {
                                window.removeEventListener('message', messageHandler);
                                resolve(event.data.response);
                            }
                        };
                        
                        window.addEventListener('message', messageHandler);
                        
                        window.postMessage({
                            action: 'load_local_settings_request',
                            source: 'incident-injector-panel'
                        }, '*');
                        
                        setTimeout(() => {
                            window.removeEventListener('message', messageHandler);
                            reject(new Error('Local settings load request timed out'));
                        }, 5000);
                    });
                    
                    if (response.success) {
                        localResult = response.settings;
                    }
                } catch (error) {
                    console.log('[Panel] Failed to load local settings via message relay:', error);
                }
            }
            
            if (localResult.event_definition) {
                eventDefinitionTextarea.value = localResult.event_definition;
                validateEventDefinition(localResult.event_definition);
            }
            
            // Update scenario button state
            updateScenarioButtonState();
            
            // Make sure scenario controls visibility matches validation state
            const definition = eventDefinitionTextarea ? eventDefinitionTextarea.value.trim() : '';
            if (definition) {
                try {
                    JSON.parse(definition);
                    if (scenarioControls) scenarioControls.style.display = 'block';
                } catch (e) {
                    if (scenarioControls) scenarioControls.style.display = 'none';
                }
            } else {
                if (scenarioControls) scenarioControls.style.display = 'none';
            }
            
            // Load sample if no event definition exists
            if (!localResult.event_definition) {
                loadSampleEventDefinition();
            }

            // Check for active scenarios and update UI
            checkForActiveScenarios();
            
        } catch (error) {
            console.error('[Panel] Error initializing panel functionality:', error);
        }
    }
    
    // Load settings (adapted from popup.js)
    async function loadSettings() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        try {
            let result = {};
            
            if (isExtensionContext()) {
                // Direct Chrome API access
                console.log('[Panel] Loading settings via direct Chrome API');
                result = await chrome.storage.sync.get([
                    'integration_key',
                    'crux_url',
                    'extension_enabled',
                    'show_alert',
                    'custom_alert_message',
                    'allow_form_continuation',
                    'redirect_to_500',
                    'trigger_crux',
                    'target_element_texts',
                    'trigger_on_click_enabled',
                    'run_scenario_on_submit',
                    'active_scenario_id',
                    'active_scenario_ids',
                    'run_stagger',
                    'change_keys',
                    'routing_keys'
                ]);
            } else {
                // Fallback: communicate through content script
                console.log('[Panel] Loading settings via message relay');
                const response = await new Promise((resolve, reject) => {
                    const messageHandler = (event) => {
                        if (event.data.action === 'settings_load_response' && event.data.source === 'incident-injector-content') {
                            window.removeEventListener('message', messageHandler);
                            resolve(event.data.response);
                        }
                    };
                    
                    window.addEventListener('message', messageHandler);
                    
                    // Send message to content script
                    window.postMessage({
                        action: 'load_settings_request',
                        source: 'incident-injector-panel'
                    }, '*');
                    
                    // Timeout after 10 seconds
                    setTimeout(() => {
                        window.removeEventListener('message', messageHandler);
                        reject(new Error('Settings load request timed out'));
                    }, 10000);
                });
                
                if (!response.success) {
                    throw new Error(response.error || 'Failed to load settings');
                }
                
                result = response.settings;
            }
            
            console.log('[Panel] Loaded settings:', result);
            console.log('[Panel] Integration key from storage:', result.integration_key ? `${result.integration_key.length} chars` : 'not set');

            const extensionEnabledToggle = panel.querySelector('#extension-enabled');
            const integrationKeyInput = panel.querySelector('#integration-key');
            const cruxUrlInput = panel.querySelector('#crux-url');
            const alertMessageTextarea = panel.querySelector('#alert-message');
            const showAlertCheckbox = panel.querySelector('#option-create-alert');
            const allowContinuationCheckbox = panel.querySelector('#option-continue-destination');
            const redirectTo500Checkbox = panel.querySelector('#option-add-500-error');
            const triggerCruxCheckbox = panel.querySelector('#option-trigger-crux');
            const targetElementsTextarea = panel.querySelector('#target-elements');
            const triggerOnClickEnabledToggle = panel.querySelector('#trigger-on-click-enabled');
            const runScenarioToggle = panel.querySelector('#option-run-scenario');

            if (integrationKeyInput) integrationKeyInput.value = result.integration_key || '';
            renderRoutingKeys(result.change_keys || result.routing_keys);
            if (cruxUrlInput) cruxUrlInput.value = result.crux_url || '';
            // Check localStorage first, then chrome.storage, then default to true
            const savedExtensionEnabled = safeStorage.get('incident_injector_extension_enabled');
            let extensionEnabled = true; // Default to true (enabled)
            if (result.extension_enabled !== undefined) {
                extensionEnabled = result.extension_enabled;
            } else if (savedExtensionEnabled !== null) {
                extensionEnabled = savedExtensionEnabled === 'true';
            }
            if (extensionEnabledToggle) extensionEnabledToggle.checked = extensionEnabled;
            if (showAlertCheckbox) showAlertCheckbox.checked = result.show_alert === true;
            if (alertMessageTextarea) alertMessageTextarea.value = result.custom_alert_message || 'Incident Injected: Form submission failed! PagerDuty incident created.';
            if (allowContinuationCheckbox) allowContinuationCheckbox.checked = result.allow_form_continuation === true;
            if (redirectTo500Checkbox) redirectTo500Checkbox.checked = result.redirect_to_500 === true;
            if (triggerCruxCheckbox) triggerCruxCheckbox.checked = result.trigger_crux === true;
            if (targetElementsTextarea) {
                // Apply defaults only on first install (undefined). A previously
                // saved empty string should stay empty, otherwise clearing the
                // field and reopening the panel would silently repopulate it
                // with defaults.
                const defaultTargets = "Submit, Login, Sign In, Register, Sign Up, Buy Now, Checkout, Purchase, Add to Cart";
                targetElementsTextarea.value = result.target_element_texts !== undefined
                    ? result.target_element_texts
                    : defaultTargets;
            }
            // Check localStorage first, then chrome.storage, then default to true
            const savedTriggerOnClick = safeStorage.get('incident_injector_trigger_on_click');
            let triggerOnClickEnabled = true; // Default to true (enabled)
            if (result.trigger_on_click_enabled !== undefined) {
                triggerOnClickEnabled = result.trigger_on_click_enabled;
            } else if (savedTriggerOnClick !== null) {
                triggerOnClickEnabled = savedTriggerOnClick === 'true';
            }
            if (triggerOnClickEnabledToggle) triggerOnClickEnabledToggle.checked = triggerOnClickEnabled;
            if (runScenarioToggle) runScenarioToggle.checked = result.run_scenario_on_submit !== false;
            const staggerToggle = panel.querySelector('#run-mode-stagger');
            if (staggerToggle) staggerToggle.checked = result.run_stagger === true;

            // Add event listeners
            addEventListeners();
            
            // Update status after settings are loaded
            setTimeout(updateStatus, 100);
            
            return result;
            
        } catch (error) {
            console.error('[Panel] Error loading settings:', error);
            return {};
        }
    }
    
    // Add event listeners to panel elements
    function addEventListeners() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        // Extension toggle
        const extensionEnabledToggle = panel.querySelector('#extension-enabled');
        if (extensionEnabledToggle) {
            extensionEnabledToggle.addEventListener('change', async (e) => {
                const value = e.target.checked;
                console.log('[Panel] Extension enabled changed to:', value);

                // Always save to localStorage for persistence
                safeStorage.set('incident_injector_extension_enabled', value.toString());

                // Try to save to chrome.storage
                try {
                    if (isExtensionContext()) {
                        await chrome.storage.sync.set({ extension_enabled: value });
                        console.log('[Panel] Extension enabled saved to both chrome.storage and localStorage');
                    } else {
                        // Page-context fallback: relay through content script so it
                        // persists to chrome.storage AND reinitializes listeners.
                        console.log('[Panel] Relaying extension_enabled via content script');
                        window.postMessage({
                            action: 'save_all_settings_request',
                            source: 'incident-injector-panel',
                            settings: { extension_enabled: value },
                            localSettings: {},
                            partial: true
                        }, '*');
                    }
                } catch (error) {
                    // Silently handle extension context invalidation
                    if (error.message && error.message.includes('Extension context invalidated')) {
                        console.log('[Panel] Extension was reloaded, saved to localStorage only');
                    } else {
                        console.log('[Panel] Failed to save to chrome.storage:', error.message);
                    }
                }
            });
        }
        
        // Integration key - validation on input, auto-save on blur
        const integrationKeyInput = panel.querySelector('#integration-key');
        if (integrationKeyInput) {
            integrationKeyInput.addEventListener('input', (e) => {
                const key = e.target.value;
                console.log('[Panel] Integration key input:', key.length, 'characters');
                validateIntegrationKey(key);
            });

            // Auto-save when user leaves the field
            integrationKeyInput.addEventListener('blur', async (e) => {
                const key = e.target.value.trim(); // Trim whitespace
                console.log('[Panel] Integration key blur - attempting to save:', key.length, 'chars');

                try {
                    if (isExtensionContext()) {
                        await new Promise((resolve, reject) => {
                            chrome.storage.sync.set({ integration_key: key }, () => {
                                if (chrome.runtime.lastError) {
                                    reject(new Error(chrome.runtime.lastError.message));
                                } else {
                                    console.log('[Panel] ✅ Integration key auto-saved to chrome.storage:', `"${key}"`);
                                    resolve();
                                }
                            });
                        });

                        // Verify the save by reading it back
                        chrome.storage.sync.get(['integration_key'], (result) => {
                            console.log('[Panel] 🔍 Verification read after save:', result.integration_key ? `"${result.integration_key}" (${result.integration_key.length} chars)` : 'not found');
                        });

                        // Update the input field to trimmed value
                        e.target.value = key;

                        // Update status after a delay to ensure storage write completes
                        setTimeout(updateStatus, 250);
                    } else {
                        // Use message relay to save via content script
                        console.log('[Panel] Using message relay to save integration key');
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'key_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };

                            window.addEventListener('message', messageHandler);

                            window.postMessage({
                                action: 'save_key_request',
                                source: 'incident-injector-panel',
                                key: key
                            }, '*');

                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Key save request timed out'));
                            }, 5000);
                        });

                        if (response.success) {
                            console.log('[Panel] ✅ Integration key saved via message relay');
                            // Update the input field to trimmed value
                            e.target.value = key;
                            // Update status
                            setTimeout(updateStatus, 250);
                        } else {
                            throw new Error(response.error || 'Failed to save key via message relay');
                        }
                    }
                } catch (error) {
                    // Silently handle extension context invalidation
                    if (error.message && error.message.includes('Extension context invalidated')) {
                        console.log('[Panel] Extension was reloaded, skipping auto-save');
                    } else {
                        console.log('[Panel] Failed to auto-save integration key:', error.message);
                    }
                }
            });

            // Also save on change as backup
            integrationKeyInput.addEventListener('change', async (e) => {
                const key = e.target.value.trim(); // Trim whitespace
                console.log('[Panel] Integration key changed - attempting to save:', key.length, 'chars');

                try {
                    if (isExtensionContext()) {
                        await new Promise((resolve, reject) => {
                            chrome.storage.sync.set({ integration_key: key }, () => {
                                if (chrome.runtime.lastError) {
                                    reject(new Error(chrome.runtime.lastError.message));
                                } else {
                                    console.log('[Panel] ✅ Integration key auto-saved via change event:', `"${key}"`);
                                    resolve();
                                }
                            });
                        });

                        // Update the input field to trimmed value
                        e.target.value = key;

                        // Update status after a delay to ensure storage write completes
                        setTimeout(updateStatus, 250);
                    } else {
                        // Use message relay to save via content script
                        console.log('[Panel] Using message relay to save integration key (change event)');
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'key_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };

                            window.addEventListener('message', messageHandler);

                            window.postMessage({
                                action: 'save_key_request',
                                source: 'incident-injector-panel',
                                key: key
                            }, '*');

                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Key save request timed out'));
                            }, 5000);
                        });

                        if (response.success) {
                            console.log('[Panel] ✅ Integration key saved via message relay (change event)');
                            // Update the input field to trimmed value
                            e.target.value = key;
                            // Update status
                            setTimeout(updateStatus, 250);
                        } else {
                            throw new Error(response.error || 'Failed to save key via message relay');
                        }
                    }
                } catch (error) {
                    console.log('[Panel] Change event save failed:', error.message);
                }
            });
        }

        // Crux URL - auto-save on blur
        const cruxUrlInput = panel.querySelector('#crux-url');
        if (cruxUrlInput) {
            // Auto-save when user leaves the field
            cruxUrlInput.addEventListener('blur', async (e) => {
                const url = e.target.value.trim();
                console.log('[Panel] Crux URL blur - attempting to save:', url.length, 'chars');

                try {
                    if (isExtensionContext()) {
                        await new Promise((resolve, reject) => {
                            chrome.storage.sync.set({ crux_url: url }, () => {
                                if (chrome.runtime.lastError) {
                                    reject(new Error(chrome.runtime.lastError.message));
                                } else {
                                    console.log('[Panel] ✅ Crux URL auto-saved to chrome.storage:', `"${url}"`);
                                    resolve();
                                }
                            });
                        });

                        // Update the input field to trimmed value
                        e.target.value = url;
                    } else {
                        // Use message relay to save via content script
                        console.log('[Panel] Using message relay to save Crux URL');
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'crux_url_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };

                            window.addEventListener('message', messageHandler);

                            window.postMessage({
                                action: 'save_crux_url_request',
                                source: 'incident-injector-panel',
                                cruxUrl: url
                            }, '*');

                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Crux URL save request timed out'));
                            }, 5000);
                        });

                        if (response.success) {
                            console.log('[Panel] ✅ Crux URL saved via message relay');
                            // Update the input field to trimmed value
                            e.target.value = url;
                        } else {
                            throw new Error(response.error || 'Failed to save Crux URL via message relay');
                        }
                    }
                } catch (error) {
                    // Silently handle extension context invalidation
                    if (error.message && error.message.includes('Extension context invalidated')) {
                        console.log('[Panel] Extension was reloaded, skipping auto-save');
                    } else {
                        console.log('[Panel] Failed to auto-save Crux URL:', error.message);
                    }
                }
            });
        }

        // Save integration key button
        const saveKeyButton = panel.querySelector('#save-key');
        if (saveKeyButton) {
            saveKeyButton.addEventListener('click', async () => {
                const key = integrationKeyInput ? integrationKeyInput.value : '';
                console.log('[Panel] Save button clicked, key length:', key.length);
                console.log('[Panel] Key value:', key); // Debug: show actual key value
                
                const validation = panel.querySelector('#key-validation');
                
                try {
                    let saveResult = false;
                    
                    if (isExtensionContext()) {
                        // Direct Chrome API access with additional safety check
                        console.log('[Panel] Using direct Chrome API for key save');
                        try {
                            // Double-check that chrome object and storage.sync are actually accessible
                            if (typeof chrome === 'undefined' || !chrome || !chrome.storage || !chrome.storage.sync || typeof chrome.storage.sync.set !== 'function') {
                                console.log('[Panel] Chrome object or storage API not available, will use message relay');
                                throw new Error('Chrome storage API not available');
                            }
                            
                            await new Promise((resolve, reject) => {
                                chrome.storage.sync.set({ integration_key: key }, () => {
                                    if (chrome.runtime && chrome.runtime.lastError) {
                                        const errorMsg = chrome.runtime.lastError.message;
                                        if (errorMsg.includes('Extension context invalidated')) {
                                            // Extension was reloaded, need to use message relay
                                            console.log('[Panel] Extension context invalidated, will try message relay');
                                            reject(new Error('CONTEXT_INVALIDATED'));
                                        } else {
                                            reject(new Error(errorMsg));
                                        }
                                    } else {
                                        console.log('[Panel] Integration key saved successfully via direct API');
                                        resolve();
                                    }
                                });
                            });
                            saveResult = true;
                        } catch (directApiError) {
                            console.log('[Panel] Direct Chrome API failed:', directApiError.message);
                            // Fall through to message relay method below
                            saveResult = false;
                        }
                    }
                    
                    if (!saveResult) {
                        // Fallback: communicate through content script
                        console.log('[Panel] Using message relay for key save');
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'key_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };
                            
                            window.addEventListener('message', messageHandler);
                            
                            // Send message to content script
                            window.postMessage({
                                action: 'save_key_request',
                                source: 'incident-injector-panel',
                                key: key
                            }, '*');
                            
                            // Timeout after 10 seconds
                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Key save request timed out'));
                            }, 10000);
                        });
                        
                        saveResult = response.success;
                        if (!saveResult) {
                            throw new Error(response.error || 'Failed to save key');
                        }
                    }
                    
                    if (saveResult) {
                        console.log('[Panel] Integration key saved successfully');
                        
                        // Show confirmation
                        if (validation) {
                            const originalText = validation.textContent;
                            const originalClass = validation.className;
                            validation.textContent = 'Saved!';
                            validation.className = 'validation-message valid';
                            setTimeout(() => {
                                validation.textContent = originalText;
                                validation.className = originalClass;
                            }, 2000);
                        }
                        
                        // Force update status after save
                        setTimeout(updateStatus, 300);
                    }
                    
                } catch (error) {
                    console.error('[Panel] Error saving integration key:', error);
                    
                    // Handle extension context invalidated error
                    if (error.message === 'CONTEXT_INVALIDATED') {
                        console.log('[Panel] Extension context invalidated, trying message relay fallback');
                        try {
                            // Try message relay as fallback
                            const response = await new Promise((resolve, reject) => {
                                const messageHandler = (event) => {
                                    if (event.data.action === 'key_save_response' && event.data.source === 'incident-injector-content') {
                                        window.removeEventListener('message', messageHandler);
                                        resolve(event.data.response);
                                    }
                                };
                                
                                window.addEventListener('message', messageHandler);
                                
                                // Send message to content script
                                window.postMessage({
                                    action: 'save_key_request',
                                    source: 'incident-injector-panel',
                                    key: key
                                }, '*');
                                
                                // Timeout after 10 seconds
                                setTimeout(() => {
                                    window.removeEventListener('message', messageHandler);
                                    reject(new Error('Key save request timed out'));
                                }, 10000);
                            });
                            
                            if (response.success) {
                                if (validation) {
                                    validation.textContent = 'Saved via refresh!';
                                    validation.className = 'validation-message valid';
                                    setTimeout(() => {
                                        const originalText = validation.textContent;
                                        const originalClass = validation.className;
                                        validation.textContent = 'Valid integration key format';
                                        validation.className = 'validation-message valid';
                                    }, 2000);
                                }
                                setTimeout(updateStatus, 300);
                            } else {
                                throw new Error(response.error || 'Message relay save failed');
                            }
                        } catch (relayError) {
                            if (validation) {
                                validation.textContent = 'Extension reloaded - please refresh page to continue';
                                validation.className = 'validation-message invalid';
                                
                                // Add a refresh button
                                setTimeout(() => {
                                    const refreshButton = document.createElement('button');
                                    refreshButton.textContent = 'Refresh Page';
                                    refreshButton.className = 'btn btn-secondary';
                                    refreshButton.style.marginTop = '8px';
                                    refreshButton.style.width = '100%';
                                    refreshButton.onclick = () => window.location.reload();
                                    validation.appendChild(refreshButton);
                                }, 1000);
                            }
                        }
                    } else {
                        // Regular error handling
                        if (validation) {
                            validation.textContent = 'Save failed: ' + error.message;
                            validation.className = 'validation-message invalid';
                        }
                    }
                }
            });
        }
        
        
        // Note: Alert message now has explicit save button instead of auto-save
        
        // Load sample button
        const loadSampleButton = panel.querySelector('#load-sample');
        if (loadSampleButton) {
            loadSampleButton.addEventListener('click', loadSampleEventDefinition);
        }
        
        // Save/Load file buttons
        const saveToFileButton = panel.querySelector('#save-to-file');
        const loadFromFileButton = panel.querySelector('#load-from-file');
        if (saveToFileButton) {
            saveToFileButton.addEventListener('click', handleSaveToFile);
        }
        if (loadFromFileButton) {
            loadFromFileButton.addEventListener('click', handleLoadFromFile);
        }
        
        // Run scenario quick button
        const runScenarioQuickButton = panel.querySelector('#run-scenario-quick');
        if (runScenarioQuickButton) {
            runScenarioQuickButton.addEventListener('click', runCurrentScenario);
        }
        
        // Event definition textarea
        const eventDefinitionTextarea = panel.querySelector('#event-definition');
        if (eventDefinitionTextarea) {
            eventDefinitionTextarea.addEventListener('input', async (e) => {
                const definition = e.target.value;
                
                // Save event definition with fallback support
                try {
                    if (isExtensionContext()) {
                        chrome.storage.local.set({ event_definition: definition });
                    } else {
                        // Fallback: save via message relay
                        window.postMessage({
                            action: 'save_event_definition_request',
                            source: 'incident-injector-panel',
                            eventDefinition: definition
                        }, '*');
                    }
                } catch (error) {
                    console.log('[Panel] Failed to auto-save event definition:', error);
                }
                
                validateEventDefinition(definition);
            });
        }
        
        // Target elements auto-save on change (no button needed)
        const targetElementsTextarea = panel.querySelector('#target-elements');

        if (targetElementsTextarea) {
            console.log('[Panel] Adding target elements auto-save listener');

            // Auto-save on blur (when user leaves the field)
            targetElementsTextarea.addEventListener('blur', async () => {
                const value = targetElementsTextarea.value;
                console.log('[Panel] Target elements blur - attempting to save:', value);

                try {
                    if (isExtensionContext()) {
                        await new Promise((resolve, reject) => {
                            chrome.storage.sync.set({ target_element_texts: value }, () => {
                                if (chrome.runtime.lastError) {
                                    reject(new Error(chrome.runtime.lastError.message));
                                } else {
                                    console.log('[Panel] ✅ Target elements auto-saved to chrome.storage');
                                    resolve();
                                }
                            });
                        });
                    } else {
                        // Use message relay to save via content script
                        console.log('[Panel] Using message relay to save target elements');
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'target_elements_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };

                            window.addEventListener('message', messageHandler);

                            window.postMessage({
                                action: 'save_target_elements_request',
                                source: 'incident-injector-panel',
                                targetElements: value
                            }, '*');

                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Target elements save request timed out'));
                            }, 5000);
                        });

                        if (response.success) {
                            console.log('[Panel] ✅ Target elements saved via message relay');
                        } else {
                            throw new Error(response.error || 'Failed to save target elements via message relay');
                        }
                    }
                } catch (error) {
                    if (error.message && error.message.includes('Extension context invalidated')) {
                        console.log('[Panel] Extension was reloaded, skipping auto-save');
                    } else {
                        console.log('[Panel] Failed to auto-save target elements:', error.message);
                    }
                }

                // Notify content script of configuration change
                const triggerEnabled = panel.querySelector('#trigger-on-click-enabled')?.checked || false;
                console.log('[Panel] Sending click config update - enabled:', triggerEnabled, 'targetElements:', value);
                window.postMessage({
                    action: 'update_click_config',
                    source: 'incident-injector-panel',
                    enabled: triggerEnabled,
                    targetElements: value
                }, '*');
            });
        }
        
        // Alert message auto-save on blur (no button needed)
        const alertMessageTextarea = panel.querySelector('#alert-message');

        if (alertMessageTextarea) {
            console.log('[Panel] Adding alert message auto-save listener');
            alertMessageTextarea.addEventListener('blur', async () => {
                const value = alertMessageTextarea.value;
                console.log('[Panel] Alert message blur - attempting to save:', value);

                try {
                    if (isExtensionContext()) {
                        await new Promise((resolve, reject) => {
                            chrome.storage.sync.set({ custom_alert_message: value }, () => {
                                if (chrome.runtime.lastError) {
                                    reject(new Error(chrome.runtime.lastError.message));
                                } else {
                                    console.log('[Panel] ✅ Alert message auto-saved to chrome.storage');
                                    resolve();
                                }
                            });
                        });
                    } else {
                        // Use message relay to save via content script
                        console.log('[Panel] Using message relay to save alert message');
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'alert_message_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };

                            window.addEventListener('message', messageHandler);

                            window.postMessage({
                                action: 'save_alert_message_request',
                                source: 'incident-injector-panel',
                                alertMessage: value
                            }, '*');

                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Alert message save request timed out'));
                            }, 5000);
                        });

                        if (response.success) {
                            console.log('[Panel] ✅ Alert message saved via message relay');
                        } else {
                            throw new Error(response.error || 'Failed to save alert message via message relay');
                        }
                    }
                } catch (error) {
                    if (error.message && error.message.includes('Extension context invalidated')) {
                        console.log('[Panel] Extension was reloaded, skipping auto-save');
                    } else {
                        console.log('[Panel] Failed to auto-save alert message:', error.message);
                    }
                }
            });
        }
        
        // Trigger options save button
        const saveTriggerOptionsButton = panel.querySelector('#save-trigger-options');
        const triggerOptionsValidation = panel.querySelector('#trigger-options-validation');
        
        if (saveTriggerOptionsButton) {
            console.log('[Panel] Adding trigger options save button listener');
            saveTriggerOptionsButton.addEventListener('click', async () => {
                console.log('[Panel] Saving trigger options...');
                
                // Get all trigger option values
                const showAlert = panel.querySelector('#option-create-alert')?.checked || false;
                const runScenario = panel.querySelector('#option-run-scenario')?.checked || false;
                const add500Error = panel.querySelector('#option-add-500-error')?.checked || false;
                const continueDestination = panel.querySelector('#option-continue-destination')?.checked || false;
                
                console.log('[Panel] Trigger options to save:', {
                    showAlert,
                    runScenario,
                    add500Error,
                    continueDestination
                });
                
                if (isExtensionContext()) {
                    try {
                        await chrome.storage.sync.set({
                            show_alert: showAlert,
                            run_scenario_on_submit: runScenario,
                            redirect_to_500: add500Error,
                            allow_form_continuation: continueDestination
                        });
                        console.log('[Panel] Trigger options saved to storage successfully');
                        
                        // Show success message
                        if (triggerOptionsValidation) {
                            triggerOptionsValidation.textContent = 'Trigger options saved successfully';
                            triggerOptionsValidation.className = 'validation-message valid';
                            setTimeout(() => {
                                triggerOptionsValidation.textContent = '';
                                triggerOptionsValidation.className = 'validation-message';
                            }, 3000);
                        }
                    } catch (error) {
                        console.log('[Panel] Failed to save trigger options:', error);
                        
                        if (triggerOptionsValidation) {
                            triggerOptionsValidation.textContent = 'Failed to save: ' + error.message;
                            triggerOptionsValidation.className = 'validation-message error';
                        }
                    }
                } else {
                    console.log('[Panel] Extension context not available - using message relay for trigger options');
                    
                    // Use message relay to save trigger options
                    try {
                        const response = await new Promise((resolve, reject) => {
                            const messageHandler = (event) => {
                                if (event.data.action === 'trigger_options_save_response' && event.data.source === 'incident-injector-content') {
                                    window.removeEventListener('message', messageHandler);
                                    resolve(event.data.response);
                                }
                            };
                            
                            window.addEventListener('message', messageHandler);
                            
                            window.postMessage({
                                action: 'save_trigger_options_request',
                                source: 'incident-injector-panel',
                                options: {
                                    show_alert: showAlert,
                                    run_scenario_on_submit: runScenario,
                                    redirect_to_500: add500Error,
                                    allow_form_continuation: continueDestination
                                }
                            }, '*');
                            
                            // Timeout after 5 seconds
                            setTimeout(() => {
                                window.removeEventListener('message', messageHandler);
                                reject(new Error('Save request timed out'));
                            }, 5000);
                        });
                        
                        if (response.success) {
                            console.log('[Panel] Trigger options saved via message relay');
                            if (triggerOptionsValidation) {
                                triggerOptionsValidation.textContent = 'Trigger options saved successfully';
                                triggerOptionsValidation.className = 'validation-message valid';
                                setTimeout(() => {
                                    triggerOptionsValidation.textContent = '';
                                    triggerOptionsValidation.className = 'validation-message';
                                }, 3000);
                            }
                        } else {
                            throw new Error(response.error || 'Failed to save trigger options');
                        }
                    } catch (relayError) {
                        console.log('[Panel] Message relay save failed:', relayError);
                        if (triggerOptionsValidation) {
                            triggerOptionsValidation.textContent = 'Failed to save: ' + relayError.message;
                            triggerOptionsValidation.className = 'validation-message error';
                        }
                    }
                }
            });
        }
        
        // Save All Settings button removed - now using auto-save on panel close
        
        // Panel close button
        const panelCloseButton = panel.querySelector('#panel-close');
        if (panelCloseButton) {
            panelCloseButton.addEventListener('click', async () => {
                // Auto-save all settings before closing
                await autoSaveAllSettings();
                // Send message to content script to hide panel
                window.postMessage({ action: 'hide_panel', source: 'incident-injector-panel' }, '*');
            });
        }
        
        // Help modal
        const helpLink = panel.querySelector('#help-link');
        const setupLink = panel.querySelector('#setup-link');
        const helpModal = panel.querySelector('#help-modal');
        const closeModal = panel.querySelector('.close');
        
        if (helpLink && helpModal) {
            helpLink.addEventListener('click', (e) => {
                e.preventDefault();
                helpModal.style.display = 'block';
            });
        }
        
        if (setupLink && helpModal) {
            setupLink.addEventListener('click', (e) => {
                e.preventDefault();
                helpModal.style.display = 'block';
            });
        }
        
        if (closeModal && helpModal) {
            closeModal.addEventListener('click', () => {
                helpModal.style.display = 'none';
            });
        }
        
        // Close modal when clicking outside
        if (helpModal) {
            helpModal.addEventListener('click', (e) => {
                if (e.target === helpModal) {
                    helpModal.style.display = 'none';
                }
            });
        }
    }
    
    // Update status (adapted from popup.js)
    async function updateStatus() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const statusDot = panel.querySelector('#status-dot');
        const statusText = panel.querySelector('#status-text');
        
        if (!isExtensionContext()) {
            // Request status from content script
            window.postMessage({
                action: 'request_status',
                source: 'incident-injector-panel'
            }, '*');
            
            if (statusDot && statusText) {
                statusDot.className = 'status-dot warning';
                statusText.textContent = 'Loading Status...';
            }
            return;
        }
        
        try {
            let result = {};

            if (isExtensionContext()) {
                // Direct Chrome API access with additional debugging
                result = await new Promise((resolve, reject) => {
                    chrome.storage.sync.get(['integration_key', 'extension_enabled'], (storageResult) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            console.log('[Panel] Raw storage result:', storageResult);
                            resolve(storageResult);
                        }
                    });
                });
            } else {
                // Fallback: communicate through content script
                const response = await new Promise((resolve, reject) => {
                    const messageHandler = (event) => {
                        if (event.data.action === 'settings_load_response' && event.data.source === 'incident-injector-content') {
                            window.removeEventListener('message', messageHandler);
                            resolve(event.data.response);
                        }
                    };
                    
                    window.addEventListener('message', messageHandler);
                    
                    // Send message to content script
                    window.postMessage({
                        action: 'load_settings_request',
                        source: 'incident-injector-panel'
                    }, '*');
                    
                    // Timeout after 5 seconds for status updates
                    setTimeout(() => {
                        window.removeEventListener('message', messageHandler);
                        reject(new Error('Status update request timed out'));
                    }, 5000);
                });
                
                if (response.success) {
                    result = response.settings;
                } else {
                    throw new Error(response.error || 'Failed to get status');
                }
            }
            
            console.log('[Panel] Storage result for status update:', result);
            console.log('[Panel] Integration key:', result.integration_key ? `${result.integration_key.length} chars` : 'not set');
            const hasKey = result.integration_key && result.integration_key.trim().length > 0; // Just check if key exists, not length
            const enabled = result.extension_enabled !== false;
            console.log('[Panel] Has key:', hasKey, 'Extension enabled:', enabled);
            
            if (statusDot && statusText) {
                if (!enabled) {
                    statusDot.className = 'status-dot inactive';
                    statusText.textContent = 'Disabled';
                } else if (!hasKey) {
                    statusDot.className = 'status-dot warning';
                    statusText.textContent = 'No Integration Key';
                } else {
                    statusDot.className = 'status-dot active';
                    statusText.textContent = 'Ready';
                }
            }
        } catch (error) {
            console.error('[Panel] Error updating status:', error);
            if (statusDot && statusText) {
                statusDot.className = 'status-dot warning';
                statusText.textContent = 'Status Update Error';
            }
        }
        
        // Update last incident time
        if (isExtensionContext()) {
            try {
                chrome.storage.local.get(['last_incident_time'], (result) => {
                    const lastIncidentSpan = panel.querySelector('#last-incident');
                    if (lastIncidentSpan) {
                    if (result.last_incident_time) {
                        const date = new Date(result.last_incident_time);
                        lastIncidentSpan.textContent = date.toLocaleString();
                    } else {
                        lastIncidentSpan.textContent = 'Never';
                    }
                }
            });
            } catch (error) {
                console.log('[Panel] Error updating last incident time:', error.message);
            }
        }
    }
    
    // Initialize toggle sections
    function initializeToggleSections() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const toggleButtons = panel.querySelectorAll('.toggle-button');
        
        toggleButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const isCollapsed = button.classList.contains('collapsed');
                const targetId = button.id.replace('toggle-', '') + '-content';
                const targetSection = panel.querySelector('#' + targetId);
                
                if (targetSection) {
                    if (isCollapsed) {
                        // Expand
                        button.classList.remove('collapsed');
                        targetSection.classList.remove('collapsed');
                    } else {
                        // Collapse
                        button.classList.add('collapsed');
                        targetSection.classList.add('collapsed');
                    }
                    button.setAttribute('aria-expanded', String(isCollapsed));
                }
            });
        });
    }
    
    // Ensure all sections remain collapsed by default
    function ensureSectionsCollapsed() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        // Get all sections that should be collapsed by default
        const collapsibleSections = [
            { button: '#toggle-pagerduty-config', content: '#pagerduty-config-content' },
            { button: '#toggle-alert-config', content: '#alert-config-content' },
            { button: '#toggle-event-definition', content: '#event-definition-content' },
            { button: '#toggle-target-config', content: '#target-config-content' }
        ];
        
        collapsibleSections.forEach(section => {
            const toggleButton = panel.querySelector(section.button);
            const contentDiv = panel.querySelector(section.content);
            
            if (toggleButton && contentDiv) {
                // Only add collapsed class if it's not already there
                if (!toggleButton.classList.contains('collapsed')) {
                    toggleButton.classList.add('collapsed');
                }
                
                if (!contentDiv.classList.contains('collapsed')) {
                    contentDiv.classList.add('collapsed');
                }
            }
        });
        
        console.log('[Panel] Ensured all sections are collapsed by default');
    }
    
    // Initialize trigger options with auto-save on change
    function initializeTriggerOptions() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;

        console.log('[Panel] Initializing trigger options with auto-save...');

        // Get all trigger option checkboxes
        const showAlertCheckbox = panel.querySelector('#option-create-alert');
        const runScenarioCheckbox = panel.querySelector('#option-run-scenario');
        const add500ErrorCheckbox = panel.querySelector('#option-add-500-error');
        const triggerCruxCheckbox = panel.querySelector('#option-trigger-crux');
        const continueDestinationCheckbox = panel.querySelector('#option-continue-destination');

        // Auto-save function for trigger options
        const autoSaveTriggerOptions = async (optionName, value) => {
            console.log(`[Panel] Auto-saving ${optionName}:`, value);

            const settings = {
                show_alert: showAlertCheckbox?.checked || false,
                run_scenario_on_submit: runScenarioCheckbox?.checked || false,
                redirect_to_500: add500ErrorCheckbox?.checked || false,
                trigger_crux: triggerCruxCheckbox?.checked || false,
                allow_form_continuation: continueDestinationCheckbox?.checked || false
            };

            try {
                if (isExtensionContext()) {
                    await chrome.storage.sync.set(settings);
                    console.log('[Panel] ✅ Trigger options auto-saved');
                } else {
                    // Use message relay
                    window.postMessage({
                        action: 'save_trigger_options_request',
                        source: 'incident-injector-panel',
                        options: settings
                    }, '*');
                    console.log('[Panel] ✅ Trigger options sent via message relay');
                }
            } catch (error) {
                console.log('[Panel] Failed to auto-save trigger options:', error.message);
            }
        };

        // Add change listeners to all checkboxes
        if (showAlertCheckbox) {
            showAlertCheckbox.addEventListener('change', () => autoSaveTriggerOptions('show_alert', showAlertCheckbox.checked));
        }
        if (runScenarioCheckbox) {
            runScenarioCheckbox.addEventListener('change', () => autoSaveTriggerOptions('run_scenario_on_submit', runScenarioCheckbox.checked));
        }
        if (add500ErrorCheckbox) {
            add500ErrorCheckbox.addEventListener('change', () => autoSaveTriggerOptions('redirect_to_500', add500ErrorCheckbox.checked));
        }
        if (triggerCruxCheckbox) {
            triggerCruxCheckbox.addEventListener('change', () => autoSaveTriggerOptions('trigger_crux', triggerCruxCheckbox.checked));
        }
        if (continueDestinationCheckbox) {
            continueDestinationCheckbox.addEventListener('change', () => autoSaveTriggerOptions('allow_form_continuation', continueDestinationCheckbox.checked));
        }

        console.log('[Panel] Trigger options auto-save listeners added');
    }
    
    // Initialize click interception
    function initializeClickInterception() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const triggerOnClickEnabledToggle = panel.querySelector('#trigger-on-click-enabled');
        const clickInterceptionConfig = panel.querySelector('#click-interception-config');
        const targetElementsTextarea = panel.querySelector('#target-elements');
        
        // Show/hide click config when toggle changes and notify content script
        function updateClickConfig() {
            if (!triggerOnClickEnabledToggle) return;
            
            const isEnabled = triggerOnClickEnabledToggle.checked;
            if (clickInterceptionConfig) {
                clickInterceptionConfig.style.display = isEnabled ? 'block' : 'none';
            }
            console.log('[Panel] Click config updated:', {
                isEnabled: isEnabled,
                display: clickInterceptionConfig ? clickInterceptionConfig.style.display : 'N/A'
            });
            
            // Notify content script about configuration change
            window.postMessage({
                action: 'update_click_config',
                source: 'incident-injector-panel',
                enabled: isEnabled,
                targetElements: targetElementsTextarea ? targetElementsTextarea.value : ''
            }, '*');
        }
        
        if (triggerOnClickEnabledToggle && clickInterceptionConfig) {
            
            triggerOnClickEnabledToggle.addEventListener('change', async (e) => {
                const value = e.target.checked;
                console.log('[Panel] Trigger on click enabled changed to:', value);

                // Always save to localStorage for persistence
                safeStorage.set('incident_injector_trigger_on_click', value.toString());

                // Try to save to chrome.storage
                try {
                    if (isExtensionContext()) {
                        await chrome.storage.sync.set({ trigger_on_click_enabled: value });
                        console.log('[Panel] Trigger on click enabled saved to both chrome.storage and localStorage');
                    }
                } catch (error) {
                    // Silently handle extension context invalidation
                    if (error.message && error.message.includes('Extension context invalidated')) {
                        console.log('[Panel] Extension was reloaded, saved to localStorage only');
                    } else {
                        console.log('[Panel] Failed to save to chrome.storage:', error.message);
                    }
                }
                updateClickConfig();
            });
            
            // Set initial state after small delay to ensure settings are loaded
            setTimeout(() => {
                updateClickConfig();
                // Debug log the initial state
                console.log('[Panel] Click interception initialized:', {
                    toggleChecked: triggerOnClickEnabledToggle ? triggerOnClickEnabledToggle.checked : 'not found',
                    configVisible: clickInterceptionConfig ? clickInterceptionConfig.style.display : 'not found'
                });
            }, 200);
            
            // Note: Target elements event listener is handled in the main addEventListeners function
            // to avoid duplicate listeners and ensure it works even if this function doesn't run
        }
    }
    
    // Validate integration key
    function validateIntegrationKey(key) {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const keyValidation = panel.querySelector('#key-validation');
        if (!keyValidation) return;
        
        if (!key) {
            keyValidation.textContent = '';
            keyValidation.className = 'validation-message';
        } else if (key.length !== 32 || !/^[a-zA-Z0-9]+$/.test(key)) {
            keyValidation.textContent = 'Invalid format. Must be 32 alphanumeric characters.';
            keyValidation.className = 'validation-message invalid';
        } else {
            keyValidation.textContent = 'Valid integration key format';
            keyValidation.className = 'validation-message valid';
            
            // Keep the section open after saving - user can manually collapse if desired
        }
    }
    
    // Run current scenario
    async function runCurrentScenario() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;

        const resultDiv = panel.querySelector('#quick-action-result');
        if (!resultDiv) return;

        try {
            // Check if extension is enabled
            const extensionEnabledToggle = panel.querySelector('#extension-enabled');
            if (extensionEnabledToggle && !extensionEnabledToggle.checked) {
                resultDiv.textContent = 'Extension is disabled. Enable it first.';
                resultDiv.className = 'test-result error';
                return;
            }

            // Auto-save all settings before running scenario
            console.log('[Panel] Auto-saving settings before running scenario...');
            await autoSaveAllSettings();

            // Note: We don't need to check isExtensionContext() here because
            // we have a fallback message relay system in place

            const eventDefinitionTextarea = panel.querySelector('#event-definition');

            if (!eventDefinitionTextarea || !eventDefinitionTextarea.value.trim()) {
                resultDiv.textContent = 'No event definition loaded';
                resultDiv.className = 'test-result error';
                return;
            }

            const selectedScenarioIds = getSelectedScenarioIds();
            if (selectedScenarioIds.length === 0) {
                resultDiv.textContent = 'Tick at least one scenario first';
                resultDiv.className = 'test-result error';
                return;
            }
            const stagger = !!panel.querySelector('#run-mode-stagger')?.checked;
            const selectedScenarioId = selectedScenarioIds[0];
            
            resultDiv.textContent = selectedScenarioIds.length > 1 ? `Running ${selectedScenarioIds.length} scenarios…` : 'Running scenario…';
            resultDiv.className = 'test-result';
            
            console.log('[Panel] Attempting to run scenario:', selectedScenarioId);
            console.log('[Panel] Extension context available:', isExtensionContext());
            console.log('[Panel] Chrome runtime available:', hasRuntimeAPI());
            console.log('[Panel] Event definition length:', eventDefinitionTextarea.value?.length || 0);
            console.log('[Panel] Event definition preview:', eventDefinitionTextarea.value?.substring(0, 200) + '...');
            
            // Send message to background script to run the scenario
            let response;
            
            // Always use message relay to avoid Chrome API issues
            console.log('[Panel] Using message relay for scenario execution');
            
            // Communicate through content script
            response = await new Promise((resolve, reject) => {
                let timeoutId;
                const messageHandler = (event) => {
                    console.log('[Panel] Received message:', event.data);
                    if (event.data.action === 'scenario_run_response' && event.data.source === 'incident-injector-content') {
                        console.log('[Panel] Got scenario response:', event.data.response);
                        clearTimeout(timeoutId);
                        window.removeEventListener('message', messageHandler);
                        resolve(event.data.response);
                    }
                };
                
                window.addEventListener('message', messageHandler);
                
                // Send message to content script
                console.log('[Panel] Sending scenario run request');
                window.postMessage({
                    action: 'run_scenario_request',
                    source: 'incident-injector-panel',
                    scenarioId: selectedScenarioId,
                    scenarioIds: selectedScenarioIds,
                    options: {
                        stagger,
                        eventDefinition: eventDefinitionTextarea.value,
                        url: window.location.href,
                        timestamp: new Date().toISOString()
                    }
                }, '*');
                
                // Timeout after 60 seconds (increased timeout for longer scenarios)
                timeoutId = setTimeout(() => {
                    console.log('[Panel] Scenario run timed out after 60 seconds');
                    window.removeEventListener('message', messageHandler);
                    reject(new Error('Scenario run request timed out but may still be running in background'));
                }, 180000);
            });
            
            if (response && response.success) {
                resultDiv.textContent = response.message || 'Scenario executed successfully';
                resultDiv.className = 'test-result success';
            } else {
                resultDiv.textContent = response?.error || 'Failed to run scenario';
                resultDiv.className = 'test-result error';
            }
        } catch (error) {
            console.log('[Panel] Scenario execution error:', error);
            // If it's a timeout error, show a more helpful message
            if (error.message.includes('timed out')) {
                resultDiv.textContent = 'Scenario may still be running in background. Check browser console for updates.';
                resultDiv.className = 'test-result warning';
            } else if (error.message.includes('Extension context invalidated') || error.message.includes('CONTEXT_INVALIDATED')) {
                resultDiv.textContent = 'Extension was reloaded. Refresh this page to continue.';
                resultDiv.className = 'test-result error';
            } else {
                resultDiv.textContent = 'Error: ' + error.message;
                resultDiv.className = 'test-result error';
            }
        }
    }
    
    // Load sample event definition
    async function loadSampleEventDefinition() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const eventDefinitionTextarea = panel.querySelector('#event-definition');
        const definitionValidation = panel.querySelector('#definition-validation');
        if (!eventDefinitionTextarea) return;
        
        try {
            
            // Since we don't have Chrome API access, request the content script to load it
            const loadPromise = new Promise((resolve, reject) => {
                // Listen for response from content script
                const messageHandler = (event) => {
                    if (event.data.action === 'sample_definition_loaded' && event.data.source === 'incident-injector-content') {
                        window.removeEventListener('message', messageHandler);
                        if (event.data.success) {
                            resolve(event.data.definition);
                        } else {
                            reject(new Error(event.data.error || 'Failed to load sample definition'));
                        }
                    }
                };
                
                window.addEventListener('message', messageHandler);
                
                // Request content script to load the sample definition
                window.postMessage({
                    action: 'load_sample_definition',
                    source: 'incident-injector-panel'
                }, '*');
                
                // Timeout after 10 seconds
                setTimeout(() => {
                    window.removeEventListener('message', messageHandler);
                    reject(new Error('Timeout loading sample definition'));
                }, 10000);
            });
            
            const sampleDefinition = await loadPromise;
            eventDefinitionTextarea.value = sampleDefinition;
            
            // Save to storage if possible
            if (isExtensionContext()) {
                await chrome.storage.local.set({ event_definition: sampleDefinition });
            }
            
            validateEventDefinition(sampleDefinition);
            
        } catch (error) {
            console.error('[Panel] Error loading sample event definition:', error);
            
            // Fallback: Load a basic sample using new schema format
            const fallbackDefinition = {
                schema_version: "1.0",
                global_config: {
                    variables: {
                        environment: "test"
                    }
                },
                event_definitions: [
                    {
                        id: "sample_scenario",
                        name: "Sample Incident Scenario",
                        description: "Basic sample scenario for testing",
                        variables: {
                            incident_key: "SAMPLE-{{incident_id}}",
                            component: "sample-component",
                            application: "Sample Application"
                        },
                        events: [
                            {
                                type: "trigger",
                                summary: "Sample incident triggered from extension",
                                severity: "error",
                                component: "{{component}}",
                                group: "testing",
                                class: "extension-test",
                                custom_details: {
                                    message: "This is a sample incident for testing the extension",
                                    timestamp: "{{timestamp}}",
                                    application: "{{application}}",
                                    source: "chrome-extension"
                                }
                            }
                        ]
                    }
                ]
            };
            
            const fallbackJson = JSON.stringify(fallbackDefinition, null, 2);
            eventDefinitionTextarea.value = fallbackJson;
            validateEventDefinition(fallbackJson);
            
            if (definitionValidation) {
                definitionValidation.textContent = 'Loaded fallback sample scenario (full samples unavailable)';
                definitionValidation.className = 'validation-message valid';
            }
            
        }
    }
    
    // Validate event definition
    function validateEventDefinition(definition) {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const definitionValidation = panel.querySelector('#definition-validation');
        const scenarioControls = panel.querySelector('#scenario-controls');
        const scenarioSelect = panel.querySelector('#scenario-select');
        
        if (!definitionValidation) return;
        
        if (!definition || !definition.trim()) {
            definitionValidation.textContent = '';
            definitionValidation.className = 'validation-message';
            renderScenarioList([]);
            setText('#definition-summary', 'empty');
            if (scenarioControls) scenarioControls.style.display = 'none';
            return;
        }
        
        try {
            const parsed = JSON.parse(definition);
            
            // Support both new (event_definitions) and legacy (scenarios) formats
            let scenarios = [];
            
            if (parsed.event_definitions && Array.isArray(parsed.event_definitions)) {
                // New format
                scenarios = parsed.event_definitions;
            } else if (parsed.scenarios && Array.isArray(parsed.scenarios)) {
                // Legacy format with scenarios array
                scenarios = parsed.scenarios;
            } else if (parsed.scenarios && typeof parsed.scenarios === 'object') {
                // Legacy format with scenarios object
                scenarios = Object.keys(parsed.scenarios).map(key => ({
                    id: key,
                    name: parsed.scenarios[key].name || key,
                    ...parsed.scenarios[key]
                }));
            } else {
                throw new Error('Must contain either "event_definitions" array or "scenarios" array/object');
            }
            
            if (scenarios.length === 0) {
                throw new Error('Must contain at least one scenario or event definition');
            }
            
            definitionValidation.textContent = `Valid definition with ${scenarios.length} scenario(s)`;
            definitionValidation.className = 'validation-message valid';
            
            renderScenarioList(scenarios);
            addReferencedKeyNames(parsed);
            setText('#definition-summary', `${scenarios.length} scenario${scenarios.length === 1 ? '' : 's'}`);
            
        } catch (error) {
            definitionValidation.textContent = `Invalid JSON: ${error.message}`;
            definitionValidation.className = 'validation-message invalid';
            setText('#definition-summary', 'invalid');
            if (scenarioControls) scenarioControls.style.display = 'none';
        }
    }
    
    // Update scenario button state
    function updateScenarioButtonState() {
        // This function would handle enabling/disabling scenario buttons
        // based on the current state
    }
    
    // Check for active scenarios
    function checkForActiveScenarios() {
        if (!isExtensionContext()) return;
        
        try {
            chrome.storage.local.get(['scenario_running'], (result) => {
            const panel = document.getElementById('incident-injector-panel');
            if (!panel) return;
            
            const scenarioIndicator = panel.querySelector('#scenario-running-indicator');
            
            if (result.scenario_running && scenarioIndicator) {
                showScenarioRunning(result.scenario_running);
            }
        });
        } catch (error) {
            console.log('[Panel] Error checking for active scenarios:', error.message);
        }
    }
    
    // Show scenario running indicator
    function showScenarioRunning(scenarioData) {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const scenarioIndicator = panel.querySelector('#scenario-running-indicator');
        const scenarioName = panel.querySelector('#scenario-name');
        const scenarioProgressFill = panel.querySelector('#scenario-progress-fill');
        
        if (scenarioIndicator) {
            let scenarioNameText = scenarioData.name || scenarioData.id || 'Unknown Scenario';
            if (scenarioData.status) {
                scenarioNameText = `${scenarioNameText} - ${scenarioData.status}`;
            }
            
            if (scenarioName) {
                scenarioName.textContent = scenarioNameText;
            }
            
            if (scenarioProgressFill && scenarioData.progress >= 0) {
                scenarioProgressFill.style.width = `${Math.min(100, Math.max(0, scenarioData.progress))}%`;
            }
            
            scenarioIndicator.style.display = 'block';
        }
    }
    
    // Listen for storage changes to update panel
    if (isExtensionContext()) {
        try {
            chrome.storage.onChanged.addListener((changes, namespace) => {
            if (namespace === 'local') {
                if (changes.scenario_running) {
                    const panel = document.getElementById('incident-injector-panel');
                    if (!panel) return;
                    
                    const scenarioIndicator = panel.querySelector('#scenario-running-indicator');
                    
                    if (changes.scenario_running.newValue) {
                        showScenarioRunning(changes.scenario_running.newValue);
                    } else if (scenarioIndicator) {
                        scenarioIndicator.style.display = 'none';
                    }
                }
            }
        });
        } catch (error) {
            console.log('[Panel] Error setting up storage change listener:', error.message);
        }
    }
    
    // Listen for messages from content script
    window.addEventListener('message', (event) => {
        if (event.data.source === 'incident-injector-content') {
            if (event.data.action === 'status_update') {
                updateStatusFromContentScript(event.data.status);
            }
        }
    });
    
    // Update status from content script message
    function updateStatusFromContentScript(statusData) {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const statusDot = panel.querySelector('#status-dot');
        const statusText = panel.querySelector('#status-text');
        const lastIncidentSpan = panel.querySelector('#last-incident');
        
        if (statusDot && statusText) {
            statusDot.className = `status-dot ${statusData.dotClass}`;
            statusText.textContent = statusData.text;
        }
        
        if (lastIncidentSpan && statusData.lastIncident) {
            lastIncidentSpan.textContent = statusData.lastIncident;
        }
        
    }
    
    // Handle saving event definition to file
    async function handleSaveToFile() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const eventDefinitionTextarea = panel.querySelector('#event-definition');
        
        try {
            // Get the current event definition
            const eventDefinition = eventDefinitionTextarea ? eventDefinitionTextarea.value.trim() : '';
            
            if (!eventDefinition) {
                console.error('[Panel] No event definition to save');
                return;
            }
            
            // Validate JSON
            try {
                JSON.parse(eventDefinition);
            } catch (e) {
                console.error('[Panel] Invalid JSON format');
                return;
            }
            
            // Create blob and download
            const blob = new Blob([eventDefinition], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            // Create temporary link and click it
            const a = document.createElement('a');
            a.href = url;
            a.download = `incident-scenarios-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            
            // Clean up URL
            setTimeout(() => {
                URL.revokeObjectURL(url);
            }, 100);
            
            console.log('[Panel] Event definition saved to file');
        } catch (error) {
            console.error('[Panel] Error saving to file:', error);
        }
    }
    
    // Handle loading event definition from file
    function handleLoadFromFile() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        
        const eventDefinitionTextarea = panel.querySelector('#event-definition');
        
        try {
            // Create a file input element
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = '.json';
            fileInput.style.display = 'none';
            
            // Add event listener for when a file is selected
            fileInput.addEventListener('change', async (event) => {
                const file = event.target.files[0];
                if (file) {
                    try {
                        const text = await file.text();
                        
                        // Validate JSON
                        try {
                            JSON.parse(text);
                        } catch (e) {
                            console.error('[Panel] Invalid JSON file');
                            return;
                        }
                        
                        // Set the content
                        if (eventDefinitionTextarea) {
                            eventDefinitionTextarea.value = text;
                            
                            // Save to storage - try direct first, then use message relay if needed
                            if (isExtensionContext()) {
                                try {
                                    if (chrome.storage && chrome.storage.local) {
                                        await chrome.storage.local.set({ event_definition: text });
                                        console.log('[Panel] Event definition saved to local storage directly');
                                    }
                                } catch (error) {
                                    console.log('[Panel] Failed to save event definition directly:', error);
                                }
                            } else {
                                // Use message relay to save
                                console.log('[Panel] Using message relay to save loaded event definition');
                                window.postMessage({
                                    action: 'save_event_definition_request',
                                    source: 'incident-injector-panel',
                                    eventDefinition: text
                                }, '*');
                            }
                            
                            // Validate the loaded definition
                            validateEventDefinition(text);
                            
                            console.log('[Panel] Event definition loaded from file');
                        }
                        
                    } catch (error) {
                        console.error('[Panel] Error reading file:', error);
                    }
                }
                
                // Clean up
                document.body.removeChild(fileInput);
            });
            
            // Append to body and trigger click
            document.body.appendChild(fileInput);
            fileInput.click();
            
        } catch (error) {
            console.error('[Panel] Error loading file:', error);
        }
    }
    
    // Initialize panel when script loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializePanel);
    } else {
        // If DOM is already loaded, check if we're in a panel context
        setTimeout(() => {
            const panel = document.getElementById('incident-injector-panel');
            if (panel) {
                initializePanel();
            }
        }, 100);
    }

    // Listen for auto-save messages from content script
    window.addEventListener('message', (event) => {
        if (event.data.action === 'auto_save_settings' && event.data.source === 'incident-injector-content') {
            console.log('[Panel] Received auto-save request from content script');
            autoSaveAllSettings().catch(error => {
                console.log('[Panel] Auto-save error:', error.message);
            });
        }
    });

    // Auto-save all settings (called when panel closes)
    async function autoSaveAllSettings() {
        console.log('[Panel] Auto-saving all settings on panel close...');

        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;

        // Only include a key in the payload if its input element is actually
        // present in the panel DOM. Writing `?.value || ''` / `?.checked || false`
        // for missing elements would silently clobber good stored values
        // with empty strings / false, wiping user config.
        const settings = {};
        const addBool = (key, selector) => {
            const el = panel.querySelector(selector);
            if (el) settings[key] = !!el.checked;
        };
        const addTrimmedString = (key, selector) => {
            const el = panel.querySelector(selector);
            if (el) settings[key] = (el.value || '').trim();
        };
        const addRawString = (key, selector) => {
            const el = panel.querySelector(selector);
            if (el) settings[key] = el.value || '';
        };

        addBool('extension_enabled', '#extension-enabled');
        addTrimmedString('integration_key', '#integration-key');
        addTrimmedString('crux_url', '#crux-url');
        addRawString('custom_alert_message', '#alert-message');
        addBool('show_alert', '#option-create-alert');
        addBool('run_scenario_on_submit', '#option-run-scenario');
        addBool('redirect_to_500', '#option-add-500-error');
        addBool('trigger_crux', '#option-trigger-crux');
        addBool('allow_form_continuation', '#option-continue-destination');
        addBool('trigger_on_click_enabled', '#trigger-on-click-enabled');
        addRawString('target_element_texts', '#target-elements');
        // Scenario selection: only when the list is actually rendered, so an
        // unloaded definition never wipes the saved selection.
        if (panel.querySelector('#scenario-list input[data-scenario-id]')) {
            const ids = getSelectedScenarioIds();
            settings.active_scenario_ids = ids;
            settings.active_scenario_id = ids[0] || '';
        }
        addBool('run_stagger', '#run-mode-stagger');
        if (panel.querySelector('#routing-key-list')) settings.change_keys = readRoutingKeys();

        console.log('[Panel] Auto-save gathering settings:', {
            keys: Object.keys(settings),
            extension_enabled: settings.extension_enabled,
            trigger_on_click_enabled: settings.trigger_on_click_enabled,
            integration_key: settings.integration_key ? `${settings.integration_key.length} chars` : 'empty/omitted',
            target_element_texts: settings.target_element_texts,
            active_scenario_id: settings.active_scenario_id
        });

        // Also save the event definition JSON to local storage (it can be large).
        // Only persist if the textarea was actually present.
        const eventDefinitionEl = panel.querySelector('#event-definition');
        const localSettings = {};
        if (eventDefinitionEl) {
            localSettings.event_definition = eventDefinitionEl.value || '';
        }

        // Save to localStorage for persistence
        Object.keys(settings).forEach(key => {
            if (key === 'extension_enabled' || key === 'trigger_on_click_enabled') {
                safeStorage.set(`incident_injector_${key}`, settings[key].toString());
            }
        });

        // Check if we're in extension context first
        if (isExtensionContext()) {
            // Direct Chrome API save
            try {
                console.log('[Panel] Auto-saving via Chrome API...');

                // Save sync settings
                await new Promise((resolve, reject) => {
                    try {
                        chrome.storage.sync.set(settings, () => {
                            if (chrome.runtime && chrome.runtime.lastError) {
                                reject(new Error(chrome.runtime.lastError.message));
                            } else {
                                resolve();
                            }
                        });
                    } catch (e) {
                        reject(e);
                    }
                });

                // Save local settings (event definition)
                if (chrome.storage.local && typeof chrome.storage.local.set === 'function') {
                    await new Promise((resolve, reject) => {
                        try {
                            chrome.storage.local.set(localSettings, () => {
                                if (chrome.runtime && chrome.runtime.lastError) {
                                    reject(new Error(chrome.runtime.lastError.message));
                                } else {
                                    resolve();
                                }
                            });
                        } catch (e) {
                            reject(e);
                        }
                    });
                }

                console.log('[Panel] ✅ Auto-save successful via Chrome API');

                // Update click configuration in content script — but only if
                // we actually gathered these fields (missing DOM → skip to
                // avoid resetting live globals to undefined).
                if ('trigger_on_click_enabled' in settings || 'target_element_texts' in settings) {
                    window.postMessage({
                        action: 'update_click_config',
                        source: 'incident-injector-panel',
                        enabled: settings.trigger_on_click_enabled,
                        targetElements: settings.target_element_texts
                    }, '*');
                }

            } catch (error) {
                // Silently handle extension context invalidation
                if (error.message && error.message.includes('Extension context invalidated')) {
                    console.log('[Panel] Extension was reloaded during close, settings not saved');
                    return; // Exit gracefully without showing error to user
                }
                console.log('[Panel] Chrome API save failed:', error.message);
            }
        } else {
            // Use message relay (page context)
            console.log('[Panel] Using message relay for auto-save (page context)');
            try {
                window.postMessage({
                    action: 'save_all_settings_request',
                    source: 'incident-injector-panel',
                    settings: settings,
                    localSettings: localSettings
                }, '*');
                console.log('[Panel] ✅ Settings sent via message relay');

                // Update click configuration in content script — but only if
                // we actually gathered these fields (missing DOM → skip to
                // avoid resetting live globals to undefined).
                if ('trigger_on_click_enabled' in settings || 'target_element_texts' in settings) {
                    window.postMessage({
                        action: 'update_click_config',
                        source: 'incident-injector-panel',
                        enabled: settings.trigger_on_click_enabled,
                        targetElements: settings.target_element_texts
                    }, '*');
                }
            } catch (msgError) {
                console.log('[Panel] Message relay failed:', msgError.message);
            }
        }
    }

    // ------------------------------------------------------------------
    // Console UI: multi-select scenarios, armed state, summaries, sheets
    // ------------------------------------------------------------------

    function setText(selector, text) {
        const el = document.getElementById('incident-injector-panel')?.querySelector(selector);
        if (el) el.textContent = text;
    }

    function getSelectedScenarioIds() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return [];
        return Array.from(panel.querySelectorAll('#scenario-list input[data-scenario-id]:checked'))
            .map(input => input.dataset.scenarioId);
    }

    function savedSelection(available) {
        const ids = Array.isArray(loadedSettings.active_scenario_ids)
            ? loadedSettings.active_scenario_ids
            : (loadedSettings.active_scenario_id ? [loadedSettings.active_scenario_id] : null);
        if (ids === null) return available.length ? [available[0]] : []; // first run: tick the first one
        return ids.filter(id => available.includes(id));
    }

    function renderScenarioList(scenarios) {
        const panel = document.getElementById('incident-injector-panel');
        const list = panel?.querySelector('#scenario-list');
        if (!list) return;
        list.replaceChildren();

        if (!scenarios.length) {
            const empty = document.createElement('li');
            empty.className = 'ii-empty';
            empty.textContent = 'No event definition loaded. Open Definition below and load the default.';
            list.appendChild(empty);
            updateSelectionUi();
            return;
        }

        const ids = scenarios.map((sc, i) => String(sc.id || i));
        const selected = new Set(savedSelection(ids));

        scenarios.forEach((sc, i) => {
            const id = ids[i];
            const li = document.createElement('li');
            const label = document.createElement('label');
            label.className = 'ii-scn';
            label.dataset.scenarioRow = id;

            const input = document.createElement('input');
            input.type = 'checkbox';
            input.dataset.scenarioId = id;
            input.checked = selected.has(id);
            const box = document.createElement('span');
            box.className = 'ii-box';
            box.setAttribute('aria-hidden', 'true');

            const name = document.createElement('span');
            name.className = 'ii-scn-name';
            name.textContent = sc.name || `Scenario ${i + 1}`;
            const count = document.createElement('span');
            count.className = 'ii-scn-count';
            const n = Array.isArray(sc.events) ? sc.events.length : 0;
            count.textContent = `${n} event${n === 1 ? '' : 's'}`;

            label.append(input, box, name, count);
            if (sc.description) {
                const desc = document.createElement('span');
                desc.className = 'ii-scn-desc';
                desc.textContent = sc.description;
                label.appendChild(desc);
            }
            input.addEventListener('change', () => {
                updateSelectionUi();
                persistScenarioSelection();
            });
            li.appendChild(label);
            list.appendChild(li);
        });
        updateSelectionUi();
    }

    function updateSelectionUi() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        const all = panel.querySelectorAll('#scenario-list input[data-scenario-id]');
        const ids = getSelectedScenarioIds();
        all.forEach(input => input.closest('.ii-scn')?.classList.toggle('is-on', input.checked));
        setText('#scenario-count', all.length ? `${ids.length} of ${all.length} selected` : '');
        setText('#run-scenario-label', ids.length > 1 ? `Run ${ids.length} scenarios` : ids.length === 1 ? 'Run scenario' : 'Select a scenario');
        const run = panel.querySelector('#run-scenario-quick');
        if (run) run.disabled = ids.length === 0;
    }

    function persistScenarioSelection() {
        const ids = getSelectedScenarioIds();
        loadedSettings.active_scenario_ids = ids;
        loadedSettings.active_scenario_id = ids[0] || '';
        const payload = { active_scenario_ids: ids, active_scenario_id: ids[0] || '' };
        try {
            if (isExtensionContext()) {
                chrome.storage.sync.set(payload);
            } else {
                window.postMessage({
                    action: 'save_scenario_selection_request',
                    source: 'incident-injector-panel',
                    scenarioId: payload.active_scenario_id,
                    scenarioIds: ids
                }, '*');
            }
        } catch (error) {
            console.log('[Panel] Failed to save scenario selection:', error.message);
        }
    }

    function updateSummaries() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        const armed = !!panel.querySelector('#extension-enabled')?.checked;
        panel.classList.toggle('ii-armed', armed);

        const on = [
            ['#option-run-scenario', 'scenarios'],
            ['#option-create-alert', 'alert'],
            ['#option-add-500-error', '500'],
            ['#option-trigger-crux', 'crux'],
            ['#option-continue-destination', 'continue']
        ].filter(([sel]) => panel.querySelector(sel)?.checked).map(([, label]) => label);
        setText('#trigger-summary', on.length ? on.join(' · ') : 'nothing');

        const clickOn = !!panel.querySelector('#trigger-on-click-enabled')?.checked;
        const targets = (panel.querySelector('#target-elements')?.value || '')
            .split(',').map(t => t.trim()).filter(Boolean);
        setText('#target-summary', !clickOn ? 'off' : targets.length ? `${targets.length} match${targets.length === 1 ? '' : 'es'}` : 'none set');

        const key = (panel.querySelector('#integration-key')?.value || '').trim();
        const named = readRoutingKeys().filter(k => k.key.length === 32).length;
        setText('#key-summary', (key.length === 32 ? `…${key.slice(-4)}` : key ? 'invalid key' : 'no key') + (named ? ` · ${named} change` : ''));
    }

    function openSheet(sheet, opener) {
        if (!sheet) return;
        sheet.style.display = 'block';
        sheet._opener = opener || null;
        sheet.querySelector('button, a')?.focus();
    }
    function closeSheet(sheet) {
        if (!sheet || sheet.style.display === 'none') return;
        sheet.style.display = 'none';
        sheet._opener?.focus?.();
    }

    function renderRunning(data) {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel) return;
        const block = panel.querySelector('#scenario-running-indicator');
        const list = panel.querySelector('#scenario-running-list');
        panel.querySelectorAll('.ii-scn.is-running').forEach(el => el.classList.remove('is-running'));
        if (!data) {
            if (block) block.style.display = 'none';
            return;
        }
        showScenarioRunning(data);
        if (list) {
            list.replaceChildren();
            (data.runs || []).forEach(run => {
                const li = document.createElement('li');
                li.className = run.state === 'done' ? 'done' : run.state === 'failed' ? 'failed' : '';
                const a = document.createElement('span');
                a.textContent = run.name || run.id;
                const b = document.createElement('span');
                b.textContent = run.state === 'done' ? 'sent' : run.state === 'failed' ? 'failed' : `${Math.round(run.progress || 0)}%`;
                li.append(a, b);
                list.appendChild(li);
                if (run.state === 'running') {
                    panel.querySelector(`.ii-scn[data-scenario-row="${CSS.escape(String(run.id))}"]`)?.classList.add('is-running');
                }
            });
        }
    }

    // ---- Change keys ----
    // One routing key for every alert; any number of named change keys, stored as
    // chrome.storage.sync.change_keys = [{ name, key }]. A change event in the
    // definition picks one with "routing_key_env": "NAME". (v2.2 used routing_keys.)
    const KEY_NAME_RE = /[^A-Za-z0-9_.-]/g;

    function readRoutingKeys() {
        const panel = document.getElementById('incident-injector-panel');
        const rows = panel ? panel.querySelectorAll('#routing-key-list .ii-rk') : [];
        const out = [];
        const seen = new Set();
        rows.forEach(row => {
            const name = (row.querySelector('.ii-rk-name')?.value || '').trim();
            const key = (row.querySelector('.ii-rk-key')?.value || '').trim();
            if (!name || seen.has(name)) return;
            seen.add(name);
            out.push({ name, key });
        });
        return out;
    }

    function addRoutingKeyRow(name = '', key = '') {
        const panel = document.getElementById('incident-injector-panel');
        const list = panel?.querySelector('#routing-key-list');
        if (!list) return null;
        const row = document.createElement('li');
        row.className = 'ii-rk';
        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.className = 'ii-rk-name ii-mono';
        nameInput.placeholder = 'PD_DEPLOY_ROUTING_KEY';
        nameInput.spellcheck = false;
        nameInput.autocomplete = 'off';
        nameInput.setAttribute('aria-label', 'Change key name');
        nameInput.value = name;
        const keyInput = document.createElement('input');
        keyInput.type = 'text';
        keyInput.className = 'ii-rk-key ii-mono';
        keyInput.placeholder = '32-char change integration key';
        keyInput.maxLength = 32;
        keyInput.spellcheck = false;
        keyInput.autocomplete = 'off';
        keyInput.setAttribute('aria-label', 'Change key');
        keyInput.value = key;
        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'ii-rk-del';
        del.textContent = '×';
        del.setAttribute('aria-label', 'Remove change key');
        const mark = () => keyInput.classList.toggle('ii-bad', keyInput.value.trim().length > 0 && keyInput.value.trim().length !== 32);
        nameInput.addEventListener('input', () => {
            const clean = nameInput.value.replace(KEY_NAME_RE, '_');
            if (clean !== nameInput.value) nameInput.value = clean;
        });
        keyInput.addEventListener('input', mark);
        nameInput.addEventListener('change', persistRoutingKeys);
        keyInput.addEventListener('change', persistRoutingKeys);
        del.addEventListener('click', () => { row.remove(); persistRoutingKeys(); updateSummaries(); });
        row.append(nameInput, keyInput, del);
        list.appendChild(row);
        mark();
        return row;
    }

    function renderRoutingKeys(keys) {
        const panel = document.getElementById('incident-injector-panel');
        const list = panel?.querySelector('#routing-key-list');
        if (!list) return;
        // Keep names the definition already asked for (rendered before settings arrived)
        const pending = readRoutingKeys().filter(k => !k.key).map(k => k.name);
        list.replaceChildren();
        const stored = Array.isArray(keys) ? keys.filter(k => k && k.name) : [];
        stored.forEach(k => addRoutingKeyRow(k.name, k.key || ''));
        pending.filter(n => !stored.some(k => k.name === n)).forEach(n => addRoutingKeyRow(n, ''));
        updateSummaries();
    }

    // Every routing_key_env named in the definition gets a row, so the user
    // only has to paste the key in.
    function addReferencedKeyNames(parsed) {
        const names = new Set();
        const walk = (defs) => (defs || []).forEach(d => (d.events || []).forEach(e => {
            if (!e || String(e.type).toLowerCase() !== 'change') return;
            const n = e.routing_key_env || e.routing_key_ref;
            if (typeof n === 'string' && n.trim()) names.add(n.trim());
        }));
        if (Array.isArray(parsed?.event_definitions)) walk(parsed.event_definitions);
        else if (parsed?.scenarios) walk(Array.isArray(parsed.scenarios) ? parsed.scenarios : Object.values(parsed.scenarios));
        const have = new Set(readRoutingKeys().map(k => k.name));
        names.forEach(n => { if (!have.has(n)) addRoutingKeyRow(n, ''); });
    }

    function persistRoutingKeys() {
        const change_keys = readRoutingKeys();
        loadedSettings.change_keys = change_keys;
        try {
            if (isExtensionContext()) {
                chrome.storage.sync.set({ change_keys });
            } else {
                window.postMessage({
                    action: 'save_all_settings_request',
                    source: 'incident-injector-panel',
                    settings: { change_keys }
                }, '*');
            }
        } catch (error) {
            console.log('[Panel] Failed to save routing keys:', error.message);
        }
    }

    function initConsoleUi() {
        const panel = document.getElementById('incident-injector-panel');
        if (!panel || panel.dataset.consoleUi) return;
        panel.dataset.consoleUi = '1';

        // Summaries + armed state follow every input in the panel
        panel.addEventListener('change', updateSummaries);
        panel.addEventListener('input', updateSummaries);
        panel.querySelector('#routing-key-add')?.addEventListener('click', () => {
            addRoutingKeyRow()?.querySelector('.ii-rk-name')?.focus();
        });
        updateSummaries();
        updateSelectionUi();

        // Version
        let version = '';
        try { version = chrome?.runtime?.getManifest?.().version || ''; } catch (e) { /* page context */ }
        if (!version) version = panel.dataset.version || '';
        if (version) {
            setText('#ii-version', `v${version}`);
            setText('#ii-about-version', `v${version}`);
        }

        // Select all / none
        panel.querySelector('#scenario-select-all')?.addEventListener('click', () => {
            panel.querySelectorAll('#scenario-list input[data-scenario-id]').forEach(i => { i.checked = true; });
            updateSelectionUi();
            persistScenarioSelection();
        });
        panel.querySelector('#scenario-select-none')?.addEventListener('click', () => {
            panel.querySelectorAll('#scenario-list input[data-scenario-id]').forEach(i => { i.checked = false; });
            updateSelectionUi();
            persistScenarioSelection();
        });

        // Format JSON
        panel.querySelector('#edit-json')?.addEventListener('click', () => {
            const ta = panel.querySelector('#event-definition');
            if (!ta || !ta.value.trim()) return;
            try {
                ta.value = JSON.stringify(JSON.parse(ta.value), null, 2);
                validateEventDefinition(ta.value);
            } catch (e) {
                validateEventDefinition(ta.value); // shows the parse error
            }
        });

        // About sheet (house info button) + Escape for both sheets
        const about = panel.querySelector('#about-dialog');
        const help = panel.querySelector('#help-modal');
        const aboutBtn = panel.querySelector('#about-button');
        aboutBtn?.addEventListener('click', () => openSheet(about, aboutBtn));
        panel.querySelector('#about-close')?.addEventListener('click', () => closeSheet(about));
        about?.addEventListener('click', (e) => { if (e.target === about) closeSheet(about); });
        panel.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape') return;
            if (about && about.style.display !== 'none') { closeSheet(about); e.stopPropagation(); }
            else if (help && help.style.display !== 'none') { help.style.display = 'none'; e.stopPropagation(); }
        });

        // Running state relayed from the content script (panel runs in page context)
        window.addEventListener('message', (event) => {
            if (event.source !== window) return;
            const d = event.data;
            if (d && d.source === 'incident-injector-content' && d.action === 'scenario_running_update') {
                renderRunning(d.scenarioRunning || null);
            }
        });
        window.postMessage({ action: 'request_scenario_running', source: 'incident-injector-panel' }, '*');
    }

})();
